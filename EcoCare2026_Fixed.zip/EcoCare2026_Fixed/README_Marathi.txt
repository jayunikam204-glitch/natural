ECOCARE 2026 — SETUP (Windows / VS Code)

1. ZIP extract करा.
2. VS Code मध्ये EcoCare2026_Fixed folder उघडा.
3. Node.js 22.5 किंवा नवीन version install असणे आवश्यक आहे.
4. VS Code Terminal उघडा (Terminal > New Terminal).
5. हे commands एकेक करून चालवा:
   npm install
   npm start
6. Browser मध्ये http://localhost:3000 उघडा.
   IMPORTANT: Index.html वर double-click करून file उघडू नका.
7. Login / Register वर क्लिक करून account तयार करा.
8. Quiz मध्ये 10 प्रश्न आहेत. उत्तर निवडल्यावर score आणि result database मध्ये save होतात.

तुमचे फोटो:
- public/images/photo1.jpg
- public/images/photo2.jpg
- public/images/photo3.jpg
- public/images/photo4.jpg
तुमचे actual photo files या नावांनी images folder मध्ये ठेवा. फोटो उपलब्ध नसल्यास त्या जागी images दिसणार नाहीत.

Database:
- पहिल्यांदा server चालवल्यावर data/ecocare.db तयार होईल.
- प्रश्न questions.json मधून पहिल्यांदा database मध्ये जातात.
- Login password hash स्वरूपात save होतो; plain password save होत नाही.

Troubleshooting:
- 'node:sqlite' error असल्यास Node.js version तपासा (node -v); Node 22.5+ वापरा.
- 'Cannot find module express' असल्यास npm install चालवा.
- बदल केल्यानंतर server थांबवण्यासाठी Ctrl+C आणि पुन्हा npm start करा.
