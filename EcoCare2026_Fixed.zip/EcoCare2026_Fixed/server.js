const path = require("path");
const crypto = require("crypto");
const { promisify } = require("util");
const express = require("express");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;
const publicDir = path.join(__dirname, "public");
const scrypt = promisify(crypto.scrypt);
const sessions = new Map();
const SESSION_COOKIE = "ecocare_session";
const isProduction = process.env.NODE_ENV === "production";

app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));
app.use(express.static(publicDir));

function cleanName(value) { return String(value || "").trim().replace(/\s+/g, " ").slice(0, 40); }
function cleanEmail(value) { return String(value || "").trim().toLowerCase().slice(0, 120); }
function getSession(req) {
  const cookie = req.headers.cookie || "";
  const match = cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${SESSION_COOKIE}=`));
  if (!match) return null;
  const token = decodeURIComponent(match.slice(SESSION_COOKIE.length + 1));
  const userId = sessions.get(token);
  if (!userId) return null;
  return { token, user: db.publicUserById(userId) };
}
function setSession(res, userId) {
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, userId);
  res.setHeader("Set-Cookie", `${SESSION_COOKIE}=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400${isProduction ? "; Secure" : ""}`);
}
function requireAuth(req, res, next) {
  const session = getSession(req);
  if (!session || !session.user) return res.status(401).json({ error: "Please log in to use the quiz." });
  req.user = session.user;
  next();
}

app.get("/", (_req, res) => res.sendFile(path.join(publicDir, "Index.html")));

app.post("/api/auth/register", async (req, res) => {
  try {
    const name = cleanName(req.body?.name);
    const email = cleanEmail(req.body?.email);
    const password = String(req.body?.password || "");
    if (name.length < 2) return res.status(400).json({ error: "Please enter a name with at least 2 characters." });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Please enter a valid email address." });
    if (password.length < 8 || password.length > 128) return res.status(400).json({ error: "Password must be 8–128 characters long." });
    const salt = crypto.randomBytes(16).toString("hex");
    const hash = await scrypt(password, salt, 64);
    const user = db.createUser(name, email, hash.toString("hex"), salt);
    if (user.error) return res.status(409).json({ error: user.error });
    setSession(res, user.id);
    res.status(201).json({ user });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ error: "Could not create your account. Please try again." });
  }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const email = cleanEmail(req.body?.email);
    const password = String(req.body?.password || "");
    const user = db.findUserByEmail(email);
    if (!user) return res.status(401).json({ error: "Email or password is incorrect." });
    const supplied = await scrypt(password, user.password_salt, 64);
    const expected = Buffer.from(user.password_hash, "hex");
    if (expected.length !== supplied.length || !crypto.timingSafeEqual(expected, supplied)) {
      return res.status(401).json({ error: "Email or password is incorrect." });
    }
    setSession(res, user.id);
    res.json({ user: { id: user.id, name: user.name, email: user.email } });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Could not log in. Please try again." });
  }
});

app.get("/api/auth/me", (req, res) => {
  const session = getSession(req);
  res.json({ user: session?.user || null });
});

app.post("/api/auth/logout", (req, res) => {
  const session = getSession(req);
  if (session) sessions.delete(session.token);
  res.setHeader("Set-Cookie", `${SESSION_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${isProduction ? "; Secure" : ""}`);
  res.json({ ok: true });
});

app.get("/api/questions", (_req, res) => res.json({ questions: db.listQuestions() }));

app.post("/api/quiz/start", requireAuth, (req, res) => {
  const attempt = db.createAttempt(cleanName(req.body?.name) || req.user.name, req.user.id);
  res.status(201).json({ attemptId: attempt.id, total: attempt.total });
});

app.post("/api/quiz/answer", requireAuth, (req, res) => {
  const attemptId = Number(req.body?.attemptId);
  const questionId = Number(req.body?.questionId);
  const selectedIndex = Number(req.body?.selectedIndex);
  if (!Number.isInteger(attemptId) || !Number.isInteger(questionId)) {
    return res.status(400).json({ error: "Quiz attempt or question is invalid." });
  }
  const result = db.saveAnswer(attemptId, questionId, selectedIndex, req.user.id);
  if (result.error) return res.status(result.status).json({ error: result.error });
  res.json(result);
});

app.get("/api/quiz/attempts", requireAuth, (req, res) => res.json({ attempts: db.listAttempts(req.user.id) }));

app.listen(PORT, () => console.log(`EcoCare server running at http://localhost:${PORT}`));
